The following modules are deprecated and its usage is discouraged.
They are no longer updated and are going to be removed in future releases of the HPE OneView Python SDK.

* activity.py
* common.py
* facilities.py
* fcsans.py
* metrics.py
* networking.py
* search.py
* security.py
* servers.py
* settings.py
* storage.py
* uncategorized.py

To consume the HPE OneView API, use the OneViewClient class instead.
In the [examples](../examples) folder, you can find samples on how to use all of the HPE OneView resources implemented by the SDK.
